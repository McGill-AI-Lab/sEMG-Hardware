#!/usr/bin/env python3
"""Manifest-driven PDF download / conversion pipeline (Python stdlib only)."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse, quote
from urllib.request import Request, build_opener, HTTPRedirectHandler

ENGINES = {"markitdown": "markitdown[pdf]", "pymupdf4llm": "pymupdf4llm", "docling": "docling", "marker": "marker-pdf"}
MAX_BYTES = 75 * 1024 * 1024


class PipelineError(Exception):
    pass


def is_public_https(url: str) -> bool:
    p = urlparse(url)
    if p.scheme != "https" or not p.hostname or p.username or p.password or p.port not in (None, 443):
        return False
    host = p.hostname.lower().rstrip(".")
    if host == "localhost" or host.endswith(".localhost") or host.endswith(".local"):
        return False
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_global
    except ValueError:
        return True


class HTTPSOnlyRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not is_public_https(newurl):
            raise PipelineError(f"Insecure or local redirect blocked: {newurl}")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def safe_path(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise PipelineError(f"Invalid relative path: {relative!r}")
    p = PurePosixPath(relative)
    if p.is_absolute() or any(part in ("..", ".") for part in p.parts):
        raise PipelineError(f"Path must stay inside the repository: {relative}")
    result = (root / Path(*p.parts)).resolve()
    try:
        result.relative_to(root.resolve())
    except ValueError:
        raise PipelineError(f"Path escapes repository: {relative}")
    return result


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}


def write_json_atomic(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".new")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def validate_manifest(manifest: dict, root: Path) -> list[dict]:
    if manifest.get("schema") != 1:
        raise PipelineError('Manifest must have "schema": 1')
    defaults = manifest.get("defaults", {})
    if not isinstance(defaults, dict):
        raise PipelineError("defaults must be an object")
    docs = manifest.get("documents", [])
    if not isinstance(docs, list) or not docs:
        raise PipelineError("documents must be a nonempty array")
    names = set()
    normalized = []
    for idx, doc in enumerate(docs, 1):
        if not isinstance(doc, dict):
            raise PipelineError(f"documents[{idx}] must be an object")
        key = doc.get("id")
        if not isinstance(key, str) or not key or not all(c.isalnum() or c in "-_" for c in key):
            raise PipelineError(f"documents[{idx}] invalid id")
        if key in names:
            raise PipelineError(f"Duplicate document id: {key}")
        names.add(key)
        url = doc.get("url")
        if not isinstance(url, str) or not is_public_https(url):
            raise PipelineError(f"{key}: URL must be public HTTPS")
        folder = doc.get("folder", "general")
        if not isinstance(folder, str):
            raise PipelineError(f"{key}: folder must be a string")
        # Validate all destinations and prevent unexpected folder traversal.
        raw_base = defaults.get("originals", "docs/datasheets/originals")
        processed_base = defaults.get("processed", "docs/datasheets/processed")
        metadata_base = defaults.get("metadata", "docs/datasheets/metadata")
        for path in (f"{raw_base}/{folder}/{key}.pdf", f"{processed_base}/{folder}/{key}", f"{metadata_base}/{folder}/{key}.json"):
            safe_path(root, path)
        engines = doc.get("converters", doc.get("converter", defaults.get("converters", ["pymupdf4llm"])))
        if isinstance(engines, str):
            engines = [engines]
        if not isinstance(engines, list) or not engines or any(x not in ENGINES for x in engines):
            raise PipelineError(f"{key}: converters must list tools from {', '.join(ENGINES)}")
        if len(set(engines)) != len(engines):
            raise PipelineError(f"{key}: duplicate converters")
        normalized.append({**doc, "id": key, "folder": folder, "converters": engines,
                           "raw_path": safe_path(root, f"{raw_base}/{folder}/{key}.pdf"),
                           "out_dir": safe_path(root, f"{processed_base}/{folder}/{key}"),
                           "meta_path": safe_path(root, f"{metadata_base}/{folder}/{key}.json")})
    return normalized


def download(url: str, dest: Path, *, limit: int = MAX_BYTES, attempts: int = 3) -> None:
    opener = build_opener(HTTPSOnlyRedirects())
    dest.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(attempts):
        temp_name = None
        try:
            req = Request(url, headers={"User-Agent": "sEMG-DocumentPipeline/1.0", "Accept": "application/pdf,*/*"})
            with opener.open(req, timeout=45) as response:
                if not is_public_https(response.url):
                    raise PipelineError("Final download URL is not public HTTPS")
                length = response.headers.get("Content-Length")
                if length and int(length) > limit:
                    raise PipelineError(f"PDF exceeds {limit // (1024*1024)} MiB limit")
                with tempfile.NamedTemporaryFile(dir=dest.parent, suffix=".download", delete=False) as output:
                    temp_name = Path(output.name)
                    total = 0
                    first = True
                    while True:
                        block = response.read(1024 * 1024)
                        if not block:
                            break
                        if first:
                            if not block.startswith(b"%PDF-"):
                                raise PipelineError("Server returned non-PDF content (possibly an HTML access page)")
                            first = False
                        total += len(block)
                        if total > limit:
                            raise PipelineError(f"Download exceeded {limit // (1024*1024)} MiB limit")
                        output.write(block)
                    if total < 30:
                        raise PipelineError("Downloaded PDF is unexpectedly small")
            temp_name.replace(dest)
            return
        except (HTTPError, URLError, OSError) as exc:
            transient = not isinstance(exc, HTTPError) or exc.code in (408, 429, 500, 502, 503, 504)
            if attempt < attempts - 1 and transient:
                time.sleep(1.0 * (2 ** attempt))
            else:
                raise PipelineError(f"Download failed for {url}: {exc}") from exc
        finally:
            if temp_name is not None:
                temp_name.unlink(missing_ok=True)


def invoke_worker(engine: str, pdf: Path, output_file: Path, source_url: str, options: dict) -> None:
    if not shutil.which("uv"):
        raise PipelineError("uv is not installed. Run: curl -LsSf https://astral.sh/uv/install.sh | sh")
    output_file.parent.mkdir(parents=True, exist_ok=True)
    worker = Path(__file__).resolve().with_name("convert_worker.py")
    with tempfile.TemporaryDirectory(dir=output_file.parent, prefix=".convert-") as stage:
        stage_path = Path(stage)
        if engine == "marker":
            # Marker CLI produces a directory with Markdown and any extracted images.
            dest = stage_path / "marker"
            dest.mkdir()
            cmd = ["uv", "run", "--no-project", "--python", "3.12", "--with", ENGINES[engine], "--",
                   "marker_single", str(pdf), "--output_dir", str(dest), "--output_format", "markdown", "--mode", "fast", "--paginate_output"]
            if options.get("marker_disable_ocr", True):
                cmd.append("--disable_ocr")
            subprocess.run(cmd, check=True)
            candidates = list(dest.rglob("*.md"))
            if not candidates:
                raise PipelineError("Marker did not create a Markdown file")
            source_md = max(candidates, key=lambda p: p.stat().st_size)
            # Copy the CLI output directory without breaking image-relative paths.
            marker_target = output_file.parent / "marker_assets"
            marker_tmp = stage_path / "marker-stage"
            shutil.copytree(source_md.parent, marker_tmp)
            if marker_target.exists():
                shutil.rmtree(marker_target)
            shutil.copytree(marker_tmp, marker_target)
            result_text = source_md.read_text(encoding="utf-8")
            # Markdown is inside marker_assets to maintain relative image references.
            final_marker_md = marker_target / source_md.name
            if not final_marker_md.exists():
                raise PipelineError("Marker asset copy failed")
            return
        stage_md = stage_path / "result.md"
        cmd = ["uv", "run", "--no-project", "--python", "3.12", "--with", ENGINES[engine], "--", "python",
               str(worker), "--engine", engine, "--input", str(pdf), "--output", str(stage_md),
               "--url", source_url]
        if options.get("docling_formula_enrichment", False) and engine == "docling":
            cmd.append("--formula-enrichment")
        subprocess.run(cmd, check=True)
        if not stage_md.exists() or stage_md.stat().st_size < 10:
            raise PipelineError(f"{engine} generated empty or missing output")
        stage_md.replace(output_file)


def index_md(root: Path, docs: list[dict], outcomes: dict[str, dict], index_file: Path) -> str:
    lines = ["# Datasheet library", "", "Original manufacturer PDFs remain the source of truth for numerical claims, equations, figures and electrical limits.", "", "| Document | PDF | Converted text | State |", "|---|---|---|---|"]
    for doc in docs:
        meta = read_json(doc["meta_path"])
        raw = doc["raw_path"]
        pdf_link = f"[PDF]({quote(Path(os.path.relpath(raw, index_file.parent)).as_posix(), safe='/')})" if raw.exists() else "—"
        links = []
        for engine in doc["converters"]:
            record = meta.get("converted", {}).get(engine, {})
            saved_path = record.get("output")
            if saved_path and safe_path(root, saved_path).exists():
                links.append(f"[{engine}]({quote(Path(os.path.relpath(safe_path(root, saved_path), index_file.parent)).as_posix(), safe='/')})")
        label = str(doc.get("title", doc["id"])).replace("|", "\\|")
        state = outcomes.get(doc["id"], {}).get("status", "not processed")
        lines.append(f"| {label} | {pdf_link} | {', '.join(links) or '—'} | {state} |")
    return "\n".join(lines) + "\n"


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Download and convert PDF datasheets from a JSON manifest")
    parser.add_argument("--manifest", default="documents.json", help="Path to JSON manifest")
    parser.add_argument("--root", help="Repository root (defaults to manifest's directory)")
    parser.add_argument("--only", action="append", help="One document ID; repeat for more")
    parser.add_argument("--dry-run", action="store_true", help="Validate and print operations without network or writes")
    parser.add_argument("--download-only", action="store_true")
    parser.add_argument("--force-download", action="store_true", help="Download even when a copy already exists")
    parser.add_argument("--force-convert", action="store_true", help="Convert even when outputs match the cached PDF")
    args = parser.parse_args(argv)
    manifest_path = Path(args.manifest).expanduser().resolve()
    if not manifest_path.exists():
        parser.error(f"Manifest not found: {manifest_path}")
    root = Path(args.root).expanduser().resolve() if args.root else manifest_path.parent
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    docs = validate_manifest(manifest, root)
    if args.only:
        missing = set(args.only) - {d["id"] for d in docs}
        if missing:
            parser.error(f"Unknown document ID(s): {', '.join(sorted(missing))}")
        docs = [d for d in docs if d["id"] in args.only]
    index = safe_path(root, manifest.get("defaults", {}).get("index", "docs/datasheets/INDEX.md"))
    outcomes = {}
    errors = 0
    for doc in docs:
        key, raw, out, meta_file = doc["id"], doc["raw_path"], doc["out_dir"], doc["meta_path"]
        print(f"\n[{key}] {doc['url']}", flush=True)
        if args.dry_run:
            print(f"  PDF: {raw}\n  Output: {out}\n  Converters: {', '.join(doc['converters'])}")
            outcomes[key] = {"status": "dry-run"}
            continue
        try:
            existing_meta = read_json(meta_file)
            needs_download = args.force_download or not raw.exists() or (existing_meta.get("url") not in (None, doc["url"]))
            if needs_download:
                print("  Downloading PDF...", flush=True)
                download(doc["url"], raw)
            else:
                print("  Using cached PDF", flush=True)
            with raw.open("rb") as f:
                if f.read(5) != b"%PDF-":
                    raise PipelineError("Cached file is not a PDF. Use --force-download")
            digest = file_hash(raw)
            metadata = {"id": key, "title": doc.get("title", key), "url": doc["url"],
                        "pdf": raw.relative_to(root).as_posix(), "sha256": digest,
                        "updated_utc": datetime.now(timezone.utc).isoformat(),
                        "converted": existing_meta.get("converted", {}) if existing_meta.get("sha256") == digest else {}}
            failures = []
            if not args.download_only:
                for engine in doc["converters"]:
                    if engine == "marker":
                        target = out / "marker_assets" / f"{key}.md"
                    else:
                        target = out / f"{engine}.md"
                    prior = metadata["converted"].get(engine, {})
                    prior_file = prior.get("output")
                    is_cached = (not args.force_convert and prior.get("pdf_sha256") == digest
                                 and prior_file is not None and safe_path(root, prior_file).exists()
                                 and prior.get("options") == doc.get("options", {}))
                    if is_cached:
                        print(f"  {engine}: cached", flush=True)
                        continue
                    try:
                        print(f"  {engine}: converting...", flush=True)
                        invoke_worker(engine, raw, target, doc["url"], doc.get("options", {}))
                        if engine == "marker":
                            marker_files = list((out / "marker_assets").rglob("*.md"))
                            if not marker_files:
                                raise PipelineError("Marker output not found after conversion")
                            target = marker_files[0]
                        metadata["converted"][engine] = {"pdf_sha256": digest,
                            "output": target.relative_to(root).as_posix(),
                            "options": doc.get("options", {}),
                            "completed_utc": datetime.now(timezone.utc).isoformat()}
                        write_json_atomic(meta_file, metadata)
                    except (PipelineError, subprocess.CalledProcessError, OSError, ValueError) as exc:
                        failures.append(f"{engine}: {exc}")
                        print(f"  ERROR converting with {engine}: {exc}", file=sys.stderr, flush=True)
            write_json_atomic(meta_file, metadata)
            if failures:
                errors += 1
            outcomes[key] = {"status": "partial failure" if failures else "ready", "errors": failures}
        except (PipelineError, OSError, ValueError) as exc:
            errors += 1
            outcomes[key] = {"status": "failed", "errors": [str(exc)]}
            print(f"  ERROR: {exc}", file=sys.stderr, flush=True)
    if not args.dry_run:
        index.parent.mkdir(parents=True, exist_ok=True)
        # Merge index across full manifest, not only --only selection.
        all_docs = validate_manifest(manifest, root)
        index.write_text(index_md(root, all_docs, outcomes, index), encoding="utf-8")
        report_path = safe_path(root, manifest.get("defaults", {}).get("report", "docs/datasheets/latest_run.json"))
        write_json_atomic(report_path, {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "results": outcomes, "failed_documents": errors})
        print(f"\nIndex: {index}")
        print(f"Report: {report_path}")
    print(f"Done. Documents: {len(docs)}, failures: {errors}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
